
import MatrixCalculator from "@/components/MatrixCalculator";

export default function Home() {
  return (
    <>
    <div>
      <MatrixCalculator />
    </div>
    </>
  );
}
