
import { useState } from "react";
import {Button,TextField,Grid,Table,TableBody,TableCell,TableContainer,TableRow,Paper,Typography,Container,Box,Card,CardContent,} from "@mui/material";

const generateRandomMatrix = (rows: number, cols: number): number[][] => {
  return Array.from({ length: rows }, () =>
    Array.from({ length: cols }, () => Math.floor(Math.random() * 10))
  );
};

const MatrixCalculator = () => {
  
  const [rows, setRows] = useState<string>("");
  const [cols, setCols] = useState<string>("");
 
  const [rowsError, setRowsError] = useState<string>("");
  const [colsError, setColsError] = useState<string>("");

  const [matrixA, setMatrixA] = useState<number[][]>([]);
  const [matrixB, setMatrixB] = useState<number[][]>([]);
  const [sumMatrix, setSumMatrix] = useState<number[][]>([]);
  const [productMatrix, setProductMatrix] = useState<number[][]>([]);

  const generateMatrices = () => {
    
    let hasError = false;
    if (rows.trim() === "") {
      setRowsError("This field is required");
      hasError = true;
    } else {
      setRowsError("");
    }
    if (cols.trim() === "") {
      setColsError("This field is required");
      hasError = true;
    } else {
      setColsError("");
    }
    if (hasError) return;

    const numRows = parseInt(rows);
    const numCols = parseInt(cols);
    if (isNaN(numRows) || isNaN(numCols) || numRows <= 0 || numCols <= 0) return;

    const A = generateRandomMatrix(numRows, numCols);
    const B = generateRandomMatrix(numRows, numCols);
    const product = A.map((row, i) => row.map((val, j) => val * B[i][j]));

    setMatrixA(A);
    setMatrixB(B);
    setProductMatrix(product);
    setSumMatrix([]); 
  };

  const handleAddMatrices = () => {
    if (matrixA.length === 0 || matrixB.length === 0) return;
    const sum = matrixA.map((row, i) => row.map((val, j) => val + matrixB[i][j]));
    setSumMatrix(sum);
  };

  const renderMatrix = (matrix: number[][], title: string) => (
    <Grid item xs={12} sm={6} key={title}>
      <Card sx={{ borderRadius: 3, boxShadow: 6 }}>
        <CardContent>
          <Typography
            variant="h6"
            align="center"
            gutterBottom
            sx={{ fontWeight: "bold", color: "primary.main" }}
          >
            {title}
          </Typography>
          <TableContainer component={Paper} sx={{ borderRadius: 2 }}>
            <Table>
              <TableBody>
                {matrix.map((row, i) => (
                  <TableRow key={i}>
                    {row.map((cell, j) => (
                      <TableCell
                        key={j}
                        align="center"
                        sx={{ fontSize: "1.2rem", fontWeight: "medium" }}
                      >
                        {cell}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </Grid>
  );

  return (
    <>
    <Container
      maxWidth="md"
      sx={{
        mt: 6,
        mb: 6,
        p: 4,
        borderRadius: 3,
        boxShadow: 4,
        background: "linear-gradient(135deg, #fdfbfb, #ebedee)",
        
      }}
    >
      <Box sx={{ textAlign: "center", mb: 4 }}>
        <Typography
          variant="h4"
          gutterBottom
          sx={{ fontWeight: "bold", color: "secondary.main" }}
        >
          Matrix Calculator
        </Typography>
        <Typography variant="subtitle1" color="textSecondary">
         Multiply and Add Matrices 
        </Typography>
      </Box>
      <Grid container spacing={2} alignItems="center" justifyContent="center" sx={{ mb: 4 }}>
        <Grid item xs={12} sm={3}>
          <TextField
            fullWidth
            label="Rows"
            type="number"
            value={rows}
            onChange={(e) => {
              setRows(e.target.value);
              if (e.target.value.trim() !== "") setRowsError("");
            }}
            variant="outlined"
            placeholder="Enter rows"
            error={Boolean(rowsError)}
            helperText={rowsError}
            sx={{ borderRadius: 2 }}
          />
        </Grid>
        <Grid item xs={12} sm={3}>
          <TextField
            fullWidth
            label="Columns"
            type="number"
            value={cols}
            onChange={(e) => {
              setCols(e.target.value);
              if (e.target.value.trim() !== "") setColsError("");
            }}
            variant="outlined"
            placeholder="Enter columns"
            error={Boolean(colsError)}
            helperText={colsError}
            sx={{ borderRadius: 2 }}
          />
        </Grid>
        <Grid item xs={12} sm={3}>
          <Button
            fullWidth
            variant="contained"
            onClick={generateMatrices}
            sx={{
              py: 1.5,
              borderRadius: 2,
              textTransform: "none",
              fontWeight: "bold",
            }}
          >
            Generate Matrices
          </Button>
        </Grid>
        
        {matrixA.length > 0 && (
          <Grid item xs={12} sm={3}>
            <Button
              fullWidth
              variant="contained"
              onClick={handleAddMatrices}
              sx={{
                py: 1.5,
                borderRadius: 2,
                textTransform: "none",
                fontWeight: "bold",
                backgroundColor: "secondary.main",
                "&:hover": { backgroundColor: "secondary.dark" },
              }}
            >
                Add Matrices
            </Button>
          </Grid>
        )}
      </Grid>

      <Grid container spacing={4}>
        {matrixA.length > 0 && renderMatrix(matrixA, "Matrix A")}
        {matrixB.length > 0 && renderMatrix(matrixB, "Matrix B")}
        {productMatrix.length > 0 && renderMatrix(productMatrix, "Product (A*B)")}
        {sumMatrix.length > 0 && renderMatrix(sumMatrix, "Sum (A + B)")}
      </Grid>
    </Container>
    </>
  );
};

export default MatrixCalculator;
